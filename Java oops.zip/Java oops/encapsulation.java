class encapsulation{  
public static void main(String[] args){  
Student s=new Student();  
s.setName("niranjan");  
System.out.println(s.getName());  
}  
}