class Bike2{  
  void run(){
System.out.println("running");
}  
}  
class Splender extends Bike{  
  void run(){
System.out.println("running safely with 60km");
}  
  
  public static void main(String args[]){  
    Bike2 b = new Splender();  
    b.run();  
  }  
}  