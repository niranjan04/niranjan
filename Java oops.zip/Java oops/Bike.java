abstract class Bike{  
  abstract void run();  
}  
class ktm extends Bike{  
void run(){System.out.println("running safely");}  
public static void main(String args[]){  
 Bike obj = new ktm();  
 obj.run();  
}  
}  